package com.ulink;

public class UlinkPidDev {
	int pid0;
	int pid1;
	int dev0;
	int dev1;
	int keytype;     // �������,0=δ����,1=�Ѽ���
	
	public UlinkPidDev(int pid0, int pid1, int dev0, int dev1, int keytype) {
		// TODO Auto-generated constructor stub
		this.pid0 = pid0;
		this.pid1 = pid1;
		this.dev0 = dev0;
		this.dev1 = dev1;
		this.keytype = keytype;    		
	}

	/**
	 * @return the pid0
	 */
	public int getPid0() {
		return pid0;
	}

	/**
	 * @return the pid1
	 */
	public int getPid1() {
		return pid1;
	}

	/**
	 * @return the dev0
	 */
	public int getDev0() {
		return dev0;
	}

	/**
	 * @return the dev1
	 */
	public int getDev1() {
		return dev1;
	}

	/**
	 * @return the keytype
	 */
	public int getKeytype() {
		return keytype;
	}

	/**
	 * @param pid0 the pid0 to set
	 */
	public void setPid0(int pid0) {
		this.pid0 = pid0;
	}

	/**
	 * @param pid1 the pid1 to set
	 */
	public void setPid1(int pid1) {
		this.pid1 = pid1;
	}

	/**
	 * @param dev0 the dev0 to set
	 */
	public void setDev0(int dev0) {
		this.dev0 = dev0;
	}

	/**
	 * @param dev1 the dev1 to set
	 */
	public void setDev1(int dev1) {
		this.dev1 = dev1;
	}

	/**
	 * @param keytype the keytype to set
	 */
	public void setKeytype(int keytype) {
		this.keytype = keytype;
	}
	
	
}
