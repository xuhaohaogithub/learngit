package com.example.vm101;

import com.ulink.UlinkNative;

import android.app.Application;

public class Vm101_Data extends Application 
{
	public String TAG ="vm101Demo";
	UlinkNative ulinkNative;// 
	
	@Override  
    public void onCreate()
	{  
        super.onCreate();  
        
        // �����߳�
    	ulinkNative = new UlinkNative();
		ulinkNative.start();

	} 
	
}
