package com.example.vm101;

import java.io.UnsupportedEncodingException;

import com.example.vm101_demo.R;
import com.ulink.UlinkNative;
import com.ulink.UlinkGPIO;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.Toast;

public class gpioActivity extends Activity {
	
	Vm101_Data vm101Data;// ȫ�ֱ���
	
	Spinner ddOneGpioNumber;
	Spinner ddOneGpioLevel;
	Spinner ddOneGpioLevel_0;
	Spinner ddOneGpioLevel_1;
	Spinner ddOneGpioLevel_2;
	Spinner ddOneGpioLevel_3;
	Spinner ddOneGpioLevel_4;
	CheckBox cbMoreGpio_0;
	CheckBox cbMoreGpio_1;
	CheckBox cbMoreGpio_2;
	CheckBox cbMoreGpio_3;
	CheckBox cbMoreGpio_4;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.gpio);
	
	// ��ȡ������Դ���
	vm101Data   	  = (Vm101_Data)getApplication();  
	ddOneGpioNumber   =(Spinner)findViewById(R.id.ddOneGpioNumber);
	ddOneGpioLevel    =(Spinner)findViewById(R.id.ddOneGpioLevel);
	ddOneGpioLevel_0  =(Spinner)findViewById(R.id.ddOneGpioLevel_0);
	ddOneGpioLevel_1  =(Spinner)findViewById(R.id.ddOneGpioLevel_1);
	ddOneGpioLevel_2  =(Spinner)findViewById(R.id.ddOneGpioLevel_2);
	ddOneGpioLevel_3  =(Spinner)findViewById(R.id.ddOneGpioLevel_3);
	ddOneGpioLevel_4  =(Spinner)findViewById(R.id.ddOneGpioLevel_4);
	cbMoreGpio_0	  =(CheckBox)findViewById(R.id.cbMoreGpio_0);;
	cbMoreGpio_1	  =(CheckBox)findViewById(R.id.cbMoreGpio_1);;
	cbMoreGpio_2	  =(CheckBox)findViewById(R.id.cbMoreGpio_2);;
	cbMoreGpio_3	  =(CheckBox)findViewById(R.id.cbMoreGpio_3);;
	cbMoreGpio_4	  =(CheckBox)findViewById(R.id.cbMoreGpio_4);;


	// ��ʼ������
	String[] items=new String[]{"0","1","2","3","4","5"};    
	ArrayAdapter<String> source=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
	ddOneGpioNumber.setAdapter(source);
	
	String[] items2=new String[]{"��","��"};    
	ArrayAdapter<String> source2=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items2);
	ddOneGpioLevel.setAdapter(source2);
	ddOneGpioLevel_0.setAdapter(source2);
	ddOneGpioLevel_1.setAdapter(source2);
	ddOneGpioLevel_2.setAdapter(source2);
	ddOneGpioLevel_3.setAdapter(source2);
	ddOneGpioLevel_4.setAdapter(source2);
	
	}
	// ���ڽ��մ��������߳�,Ϊ��������,������Ҫʹ��message������,���صĽ��
    Handler hRecvUart = new Handler() 
    {
    	@Override
		public void handleMessage(Message msg) 
    	{
			switch (msg.what) 
			{
			case UlinkNative.CMD_GPIO_READ:		// ��gpio		
				if ( msg.arg1 < 0 )
				{
					Toast.makeText(gpioActivity.this, "��GPIOʧ��", Toast.LENGTH_SHORT).show();					
					break;
				}
				Toast.makeText(gpioActivity.this, "��GPIO�ɹ�", Toast.LENGTH_SHORT).show();
				ddOneGpioLevel.setSelection(((UlinkGPIO)msg.obj).value);
				break;
			case UlinkNative.CMD_GPIO_WRITE:	// дgpio
				if ( msg.arg1 < 0 )
				{
					Toast.makeText(gpioActivity.this, "дGPIOʧ��", Toast.LENGTH_SHORT).show();					
					break;
				}
				Toast.makeText(gpioActivity.this, "дGPIO�ɹ�", Toast.LENGTH_SHORT).show();
				break;
			case UlinkNative.CMD_GPIO_MULPWRITE:	// дgpio
				if ( msg.arg1 < 0 )
				{
					Toast.makeText(gpioActivity.this, "д��GPIOʧ��", Toast.LENGTH_SHORT).show();					
					break;
				}
				Toast.makeText(gpioActivity.this, "д��GPIO�ɹ�", Toast.LENGTH_SHORT).show();
				break;
			default:
				super.handleMessage(msg);	
			break;
			}
			
    	}
    };
    
	// ����gpio���ð��� 
    public void OnClick_OneGpio(View view)
    {    
     	UlinkGPIO ulinkGPIO = new UlinkGPIO();
    	ulinkGPIO.pin  = (int)ddOneGpioNumber.getSelectedItemId();
    	ulinkGPIO.mode = UlinkNative.eGPIO_Output;
    	ulinkGPIO.value= (int)ddOneGpioLevel.getSelectedItemId();
       	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvUart, UlinkNative.CMD_GPIO_WRITE, ulinkGPIO);  	
    }
    // ����gpio����ȡ����
    public void OnClick_OneGpioRead(View view)
    {    
      	UlinkGPIO ulinkGPIO = new UlinkGPIO();
    	ulinkGPIO.pin  = (int)ddOneGpioNumber.getSelectedItemId();
    	ulinkGPIO.mode = UlinkNative.eGPIO_Input;
       	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvUart, UlinkNative.CMD_GPIO_READ, ulinkGPIO);  	
    }
    // ���gpio��pinѡ��box 0
    public void OnClick_cbMoreGpio_0(View view)
    {    
    	
    }
    // ���gpio��pinѡ��box 1
    public void OnClick_cbMoreGpio_1(View view)
    {    
    	
    }
    // ���gpio��pinѡ��box 2
    public void OnClick_cbMoreGpio_2(View view)
    {    
    	
    }
    // ���gpio��pinѡ��box 3
    public void OnClick_cbMoreGpio_3(View view)
    {    
    	
    }
    // ���gpio��pinѡ��box 4
    public void OnClick_cbMoreGpio_4(View view)
    {    
    	
    }
    private int getMorePin()
    {
    	int ret = 0;
    	if (cbMoreGpio_0.isChecked()) ret += 1;
    	if (cbMoreGpio_1.isChecked()) ret += 2;
    	if (cbMoreGpio_2.isChecked()) ret += 4;
    	if (cbMoreGpio_3.isChecked()) ret += 8;
    	if (cbMoreGpio_4.isChecked()) ret += 16;
    	return ret;
    }
    private int getMoreValue()
    {
    	int ret = 0;   	
    	if (ddOneGpioLevel_0.getSelectedItemId()==1) ret += 1;
    	if (ddOneGpioLevel_1.getSelectedItemId()==1) ret += 2;
    	if (ddOneGpioLevel_2.getSelectedItemId()==1) ret += 4;
    	if (ddOneGpioLevel_3.getSelectedItemId()==1) ret += 8;
    	if (ddOneGpioLevel_4.getSelectedItemId()==1) ret += 16;
    	return ret;
    }
    // ���gpio�����ð���
    public void OnClick_MoreGpio(View view)
    {    
    	UlinkGPIO ulinkGPIO = new UlinkGPIO();
    	ulinkGPIO.pin  = getMorePin();
    	ulinkGPIO.mode = UlinkNative.eGPIO_Input;
    	ulinkGPIO.value= getMoreValue();
       	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvUart, UlinkNative.CMD_GPIO_MULPWRITE, ulinkGPIO);  	
     	
    }
    // ���gpio����ȡ����
    public void OnClick_MoreGpioRead(View view)
    {    
    	
    }
}
