package com.example.vm101;

import com.example.vm101_demo.R;
import com.ulink.UlinkNative;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.UnsupportedEncodingException; 
import java.net.URLDecoder;  
import java.net.URLEncoder;  
  
public class uartActivity extends Activity {
	public static final int MSG_RECV_UART = 0x1001;

	Vm101_Data vm101Data;// ȫ�ֱ���
	EditText eUart_Send_Buff;
	TextView tRecvUart;
    int bOnPause;		// ��ͣ��־λ
    int bOnDestroy;		// �˳���־λ
    int bSendRecv;		// �շ�һ��ģʽ
    int bHex;			// hex��ʾģʽ
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.uart);
	
	// ��ȡ������Դ���
	vm101Data   	= (Vm101_Data)getApplication();  
	eUart_Send_Buff =(EditText)findViewById(R.id.eUart_Send_Buff);  
	tRecvUart 		=(TextView)findViewById(R.id.tRecvUart);  
	tRecvUart.setMovementMethod(ScrollingMovementMethod.getInstance()); 
	// ��ʼ������
	bOnPause 	= 0;	// �����̱߳�־λ��0=���У�1=��ͣ��2=�˳�
	bOnDestroy	= 0;	// �˳��ɹ��� ��1
	bSendRecv   = 0;	// Ĭ�ϲ�ʹ���շ�һ��ģ��
	bHex        = 0;	// Ĭ�ϲ�ʹ��hex��ʾģʽ
    
	// �����߳�
	thRecvUart.start();
	}
	// ת�������ַ�hex
	private byte getOneHex(byte ucChar)
	{
		byte ret = 0;
		if (ucChar>='0' && ucChar<='9')
		{
			ret = (byte)(ucChar-'0');
		}
		else if (ucChar>='A'&& ucChar<='F')
		{
			ret = (byte)(ucChar-'A'+0x0A);
		}
		else if (ucChar>='a'&& ucChar<='f')
		{
			ret = (byte)(ucChar-'a'+0x0A);
		}
		return ret;
	}
	private byte[] strToHex(String sStr,int bhex)
	{
		byte[]btmp=null;
		int len,i,j;
		try 
		{
			if ( bhex == 1 )// ��Ҫת��hex
			{
				sStr = sStr.replace(" ", "");
				sStr = sStr.replace(",", "");
				sStr = sStr.replace("\r", "");
				sStr = sStr.replace("\n", "");
				
				byte[]btmp2 = sStr.getBytes("GBK");
				len = btmp2.length;
				if ( len > 0 )
				{
					if (len%2==1) len +=1;
					btmp = new byte[len/2];
					for ( i=0, j=0; i<len; i+=2,j++)
					{
						byte ucH = getOneHex(btmp2[i]);
						byte ucL;
						if ((i+1) >= btmp2.length)
						{
							ucL = 0;
						}
						else
						{
							ucL = getOneHex(btmp2[i+1]);	
						}
						
						btmp[j] = (byte)((ucH<<4)|ucL);
					}	
				}			
			}
			else
			{			
				btmp = sStr.getBytes("GBK");
			}
			
		} 
		catch (UnsupportedEncodingException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return btmp;
	}
	// ���ʹ�������  
    public void OnClick_SendUart(View view)
    {
    	// ��ȡ���ڷ�������
    	int ret = -1;
		byte recvbuf[]= new byte[256];
		String stmp = eUart_Send_Buff.getText().toString();
		
		if (stmp.length() == 0)  return;
	
		byte[]btmp = strToHex(stmp,bHex);
		
		if (btmp == null) return;
		
		if (bSendRecv==0)
		{
        	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvUart, UlinkNative.CMD_SEND_SERIAL, btmp);
		}
		else 
		{
           	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvUart, UlinkNative.CMD_TXRX_SERIAL, btmp);                        			
		}
    }
    
    // ��ͣ�߳�
    @Override
	protected void onPause() 
    {
		// TODO Auto-generated method stub
    	bOnPause = 1;
		super.onPause();
	}

    // �ָ��߳�
    @Override
	protected void onResume() {
		// TODO Auto-generated method stub
    	bOnPause = 0;
		super.onResume();
	}

    // �˳�Activity
    @Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
    	super.onDestroy();
    	bOnPause = 2;   	
	}
	

    private String HexTostr(byte[] bhexbytearry,int arrylen,int bhex)
	{
		int j;
		
		String str="";  
		try 
    	{  
			if ( bhex == 1 )
			{
				for (j=0; j<arrylen; j++)
				{
					str += String.format("%02X ",bhexbytearry[j]);
				}
			}
			else
			{				
				str = new String(bhexbytearry,0,arrylen,"GBK");  
			}
    	} 
    	catch (UnsupportedEncodingException e) 
    	{  
            e.printStackTrace();  
        } 
		return str;
		
	}
    // ���ڽ��մ��������߳�,Ϊ��������,������Ҫʹ��message������,���صĽ��
    Handler hRecvUart = new Handler() 
    {
    	@Override
		public void handleMessage(Message msg) 
    	{
			switch (msg.what) 
			{
			case UlinkNative.CMD_READ_SERIAL: // ��ʾ����������Ϣ
			case UlinkNative.CMD_TXRX_SERIAL: // ���շ�һ�����ʽ���ʹ�������
				if ( msg.arg1 < 0 )
				{
					if ( msg.what == UlinkNative.CMD_TXRX_SERIAL )
					{
						Toast.makeText(uartActivity.this, "�շ�һ�����ʧ��", Toast.LENGTH_SHORT).show();					
					}
					break;
				}
				if ( msg.arg1 > 0 )
				{
					// �����ת��
					String str = HexTostr((byte[])(msg.obj),msg.arg1,bHex);
		    		String stmp = tRecvUart.getText()+str;
					tRecvUart.setText(stmp);
				}	
				break;
			case UlinkNative.CMD_SEND_SERIAL:// ���ʹ�������
				if ( msg.arg1 < 0 )
				{
					Toast.makeText(uartActivity.this, "����ʧ��", Toast.LENGTH_SHORT).show();					
					break;
				}
				Toast.makeText(uartActivity.this, "���ͳɹ�", Toast.LENGTH_SHORT).show();
				break;
			default:
				super.handleMessage(msg);	
			break;
			}
			
    	}
    };
    
    
    // ���մ��������߳�,��������
    Thread thRecvUart = new Thread() 
    {  
        @Override  
        public void run() 
        { 
         	while( bOnPause != 2 )// �����̱߳�־λ��0=���У�1=��ͣ��2=�˳�
        	{
        		if ( bOnPause == 0 && bSendRecv==0 )// bSendRecv==0,���շ�һ��
        		{
        			// ��û�з�������ʱ����ȡ��������
        			if (vm101Data.ulinkNative.busy == 0) 
            		{
            	    	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvUart, UlinkNative.CMD_READ_SERIAL, (Object)null);            	        	
            		}            				
        		}
        		
        		try 
        		{  
                    Thread.sleep(300);  
                } 
        		catch (Exception ex) 
        		{  
                }
        		
        	}
             
        }  
    };  
    
    // ��ս�����Ϣ
    public void OnClick_ClearUart(View view)
    {
    	tRecvUart.setText("");
    }
    // �շ�һ��ģ�飬onclick�¼�����
    public void OnClick_cbSendRecv(View view)
    {
    	if (bSendRecv == 0)
    	{
    		bSendRecv = 1;	// ִ��һ��ģ��
    	}
    	else
    	{
    		bSendRecv = 0;
    	}
    }
    
    // hex��ʾ
    public void OnClick_cbHex(View view)
    {
    	if (bHex == 0)
    	{
    		bHex = 1;	// hex��ʾ
    	}
    	else
    	{
    		bHex = 0;
    	}
    }
}
