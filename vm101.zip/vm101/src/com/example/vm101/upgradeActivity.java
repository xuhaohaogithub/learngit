package com.example.vm101;

import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;

import com.example.vm101_demo.R;
import com.ulink.UlinkGPIO;
import com.ulink.UlinkNative;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class upgradeActivity extends Activity {
	final static public int	FILE_SELECT_CODE		= 0x8001;	// �ļ�ѡ��

	Vm101_Data vm101Data;// ȫ�ֱ���
	TextView tUpgradefile;
	TextView tVersion;
	Button bUpgrade;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.upgrade);
	
	// ��ȡ������Դ���
	vm101Data     = (Vm101_Data)getApplication();  
	tUpgradefile  =(TextView)findViewById(R.id.tUpgradefile);;
	tVersion	  =(TextView)findViewById(R.id.tVersion);;
	bUpgrade	  =(Button)findViewById(R.id.bUpgrade);;
	
	}
	
	// ���ڽ��մ��������߳�,Ϊ��������,������Ҫʹ��message������,���صĽ��
    Handler hRecvUart = new Handler() 
    {
    	@Override
		public void handleMessage(Message msg) 
    	{
			switch (msg.what) 
			{
			case UlinkNative.CMD_WIFISDKVER_QURY:		// ���汾��		
				if ( msg.arg1 < 0 )
				{
					Toast.makeText(upgradeActivity.this, "���汾ʧ��", Toast.LENGTH_SHORT).show();
					break;
				}
				// �����ת��
	    		String str=null;  
	    		try 
	        	{  
	    			str = new String((byte[])msg.obj,0,msg.arg1,"GBK");  
    	    	} 
	        	catch (UnsupportedEncodingException e) 
	        	{  
	                e.printStackTrace();  
	            }  
	    		tVersion.setText(str);
				break;
			case UlinkNative.CMD_WIFIUPDATE_TRI:		// �����̼�	
				bUpgrade.setText("�̼�����");
				bUpgrade.setEnabled(true);
				if ( msg.arg1 < 0 )
				{
					ShowMessage("����ʧ��");
					break;
				}
				ShowMessage("�����ɹ�");
				break;
			default:
				super.handleMessage(msg);	
			break;
			}
			
    	}
    };
    private void ShowMessage(String sMess)
    {
    	new  AlertDialog.Builder(this)    
    	   
    	                .setTitle("Message" )  
    	   
    	                .setMessage(sMess )  
    	   
    	                .setPositiveButton("ȷ��" ,  null )  
    	   
    	                .show(); 
    }
	// ���汾����Ϣ
    public void OnClick_bReadVersion(View view)
    {
    	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvUart, UlinkNative.CMD_WIFISDKVER_QURY, (Object)null);            	        	    	
    }
    
    // ѡ�������ļ�
    public void OnClick_bSelectUpgradeFile(View view)
    {
    	Intent intent = new Intent(Intent.ACTION_GET_CONTENT); 
        intent.setType("*/*"); 
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        
        try 
        {
        	startActivityForResult( intent, FILE_SELECT_CODE);
                
        } catch (android.content.ActivityNotFoundException ex) 
        {
            Toast.makeText(this, "Please install a File Manager.",  Toast.LENGTH_SHORT).show();
        }
    	
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)  
    {
        switch (requestCode) 
        {
            case FILE_SELECT_CODE:      
            
            if (resultCode == RESULT_OK) 
            {  
                // Get the Uri of the selected file 
                Uri uri = data.getData();
                tUpgradefile.setText(uri.getPath());
            }         
            else
            {
            	tUpgradefile.setText("");
            }
            break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    // �̼�����
    public void OnClick_bUpgrade(View view)
    {
    	if ( tUpgradefile.getText().toString().length() == 0 )
    	{
    		ShowMessage("��ѡ�������ļ�");
    		return;
    	}
    	
    	try
    	{   
            FileInputStream fin = new FileInputStream(tUpgradefile.getText().toString());   
     
            int length = fin.available();   
            if ( length >= 0x40000 )
            {
           		ShowMessage("�ļ�̫����ѡ����ȷ���ļ�");
        		return;         	
            }
            
            // ��ȡ�ļ�
            byte [] buffer = new byte[length];   
            fin.read(buffer);     
            fin.close();
            
            // ����
            bUpgrade.setText("�����С�����");
            bUpgrade.setEnabled(false);
        	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvUart, UlinkNative.CMD_WIFIUPDATE_TRI, buffer);            	        	    	
                   
       }       
       catch(Exception e)
       {   
        e.printStackTrace();   
       }   
    	
    }
    
}
