package com.example.vm101;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Date;

import com.example.vm101_demo.R;
import com.ulink.UlinkGPIO;
import com.ulink.UlinkNative;
import com.ulink.UlinkTimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

public class timeActivity extends Activity {
	Vm101_Data vm101Data;// ȫ�ֱ���
	Spinner ddPinNumber;
	Spinner ddPinLevel;
	Spinner ddSaveNumber;
	RadioButton radioZHOU;
	RadioButton radioDUAN;
	RadioButton radioUART;
	RadioButton radioGPIO;
	
	CheckBox cbZHOU_1;
	CheckBox cbZHOU_2;
	CheckBox cbZHOU_3;
	CheckBox cbZHOU_4;
	CheckBox cbZHOU_5;
	CheckBox cbZHOU_6;
	CheckBox cbZHOU_7;
	
	EditText eZHOU_Time;
	EditText eDUAN_Star_Date;
	EditText eDUAN_Star_Time;
	EditText eDUAN_End_Date;
	EditText eDUAN_End_Time;
	EditText eDUAN_Times;
	EditText eUART_Buff;
	
	Calendar c;
	int iZHOU_Time_Hour;	// �ܶ�ʱ��ʱ
	int iZHOU_Time_Minute;	// �ܶ�ʱ����
	int iZHOU_Time_Second;	// �ܶ�ʱ����
	
	int iDUAN_Star_Data_Year;	// �ζ�ʱ����ʼʱ�䣬��
	int iDUAN_Star_Data_Month;	// �ζ�ʱ����ʼʱ�䣬��
	int iDUAN_Star_Data_Day;	// �ζ�ʱ����ʼʱ�䣬��	
	int iDUAN_Star_Time_Hour;	// �ζ�ʱ����ʼʱ�䣬ʱ
	int iDUAN_Star_Time_Minute;	// �ζ�ʱ����ʼʱ�䣬��
	int iDUAN_Star_Time_Second;	// �ζ�ʱ����ʼʱ�䣬��
	
	int iDUAN_End_Data_Year;	// �ζ�ʱ������ʱ�䣬��
	int iDUAN_End_Data_Month;	// �ζ�ʱ������ʱ�䣬��
	int iDUAN_End_Data_Day;		// �ζ�ʱ������ʱ�䣬��	
	int iDUAN_End_Time_Hour;	// �ζ�ʱ������ʱ�䣬ʱ
	int iDUAN_End_Time_Minute;	// �ζ�ʱ������ʱ�䣬��
	int iDUAN_End_Time_Second;	// �ζ�ʱ������ʱ�䣬��
	
	static final int WEEK_1 = 0x01;
    static final int WEEK_2 = 0x02;
    static final int WEEK_3 = 0x04;
	static final int WEEK_4 = 0x08;
    static final int WEEK_5 = 0x10;
    static final int WEEK_6 = 0x20;
    static final int WEEK_7 = 0x40;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.time);
	
	// ��ȡ������Դ���
	vm101Data  		=(Vm101_Data)getApplication();  
	ddPinNumber   	=(Spinner)findViewById(R.id.ddPinNumber);
	ddPinLevel    	=(Spinner)findViewById(R.id.ddPinLevel);
	ddSaveNumber  	=(Spinner)findViewById(R.id.ddSaveNumber);
	
	radioZHOU		=(RadioButton)findViewById(R.id.radioZHOU);
	radioDUAN		=(RadioButton)findViewById(R.id.radioDUAN);
	radioUART		=(RadioButton)findViewById(R.id.radioUART);
	radioGPIO		=(RadioButton)findViewById(R.id.radioGPIO);
	
	cbZHOU_1		=(CheckBox)findViewById(R.id.cbZHOU_1);
	cbZHOU_2		=(CheckBox)findViewById(R.id.cbZHOU_2);
	cbZHOU_3		=(CheckBox)findViewById(R.id.cbZHOU_3);
	cbZHOU_4		=(CheckBox)findViewById(R.id.cbZHOU_4);
	cbZHOU_5		=(CheckBox)findViewById(R.id.cbZHOU_5);
	cbZHOU_6		=(CheckBox)findViewById(R.id.cbZHOU_6);
	cbZHOU_7		=(CheckBox)findViewById(R.id.cbZHOU_7);

	eZHOU_Time		=(EditText)findViewById(R.id.eZHOU_Time);
	eDUAN_Star_Date	=(EditText)findViewById(R.id.eDUAN_Star_Date);
	eDUAN_Star_Time	=(EditText)findViewById(R.id.eDUAN_Star_Time);
	eDUAN_End_Date	=(EditText)findViewById(R.id.eDUAN_End_Date);
	eDUAN_End_Time	=(EditText)findViewById(R.id.eDUAN_End_Time);
	eDUAN_Times		=(EditText)findViewById(R.id.eDUAN_Times);
	eUART_Buff		=(EditText)findViewById(R.id.eUART_Buff);
	// ��ʼ������
	String[] items=new String[]{"0","1","2","3","4"};    
	ArrayAdapter<String> source=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
	ddPinNumber.setAdapter(source);
	
	String[] items2=new String[]{"OFF","ON"};    
	ArrayAdapter<String> source2=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items2);
	ddPinLevel.setAdapter(source2);
	
	String[] items3=new String[]{"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29"};    
	ArrayAdapter<String> source3=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items3);
	ddSaveNumber.setAdapter(source3);
	      
	c = Calendar.getInstance();	// ��ȡ��ǰϵͳʱ��  
	Show_eZHOU_Time(c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),0);
	Show_eDUAN_Star_Data(c.get(Calendar.YEAR), c.get(Calendar.MONTH),  c.get(Calendar.DAY_OF_MONTH));
	Show_eDUAN_Star_Time(c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),0);
	Show_eDUAN_End_Data(c.get(Calendar.YEAR), c.get(Calendar.MONTH),  c.get(Calendar.DAY_OF_MONTH));
	Show_eDUAN_End_Time(c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),0);
	}

	// ���ڽ��մ��������߳�,Ϊ��������,������Ҫʹ��message������,���صĽ��
    Handler hRecvTimer = new Handler() 
    {
    	@Override
		public void handleMessage(Message msg) 
    	{
			switch (msg.what) 
			{
			case UlinkNative.CMD_CLOCK_SET:		// ���ö�ʱ		
				if ( msg.arg1 < 0 )
				{
					Toast.makeText(timeActivity.this, "���ö�ʱʧ��", Toast.LENGTH_SHORT).show();					
					break;
				}
				Toast.makeText(timeActivity.this, "���ö�ʱ�ɹ�", Toast.LENGTH_SHORT).show();
				break;
			case UlinkNative.CMD_CLOCK_GET:		//��ȡģ��ģ���Ѿ����õĶ�ʱ
				if ( msg.arg1 < 0 )
				{
					Toast.makeText(timeActivity.this, "����ʱʧ��", Toast.LENGTH_SHORT).show();					
					break;
				}
				Toast.makeText(timeActivity.this, "����ʱ�ɹ�", Toast.LENGTH_SHORT).show();
				ShowUlinkTimer((UlinkTimer)msg.obj);
				break;
			case UlinkNative.CMD_CLOCK_DEL:		//ɾ����ʱ
				if ( msg.arg1 < 0 )
				{
					Toast.makeText(timeActivity.this, "ɾ����ʱʧ��", Toast.LENGTH_SHORT).show();					
					break;
				}
				Toast.makeText(timeActivity.this, "ɾ����ʱ�ɹ�", Toast.LENGTH_SHORT).show();
				break;
			default:
				super.handleMessage(msg);	
			break;
			}
			
    	}
    };
    
	// �ܶ�ʱradio����  
    public void OnClick_radioZHOU(View view)
    {
    	SetRadioGroup(0);
    }
    
    // �ζ�ʱ radioѡ��  
    public void OnClick_radioDUAN(View view)
    {
    	SetRadioGroup(1);
    }
    // ���ʹ�������  
    public void OnClick_radioUART(View view)
    {
    	SetRadioGroup(2);		
    }
    // gpio����
    public void OnClick_radioGPIO(View view)
    {
    	SetRadioGroup(3);		
    }
    // ����ʱ����
    public void OnClick_bReadTime(View view)
    {
    	UlinkTimer ulinkTimer = new UlinkTimer();

    	// ��ǰʱ���������Ϊ0�����ߵ�ǰʱ�䣬���ܲ�����ʼ��
    	ulinkTimer.currentm 	= 0l;		/* ��ǰʱ�� */	
    	ulinkTimer.mon_unixtm	= 0l;		/* ����һ 00:00��unixʱ��֡*/	
    	ulinkTimer.ulen         = 0;		/* �����������Ϊ0*/
       	ulinkTimer.clk_idx		= (int)ddSaveNumber.getSelectedItemId();		/* ���*/
       	
    	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvTimer, UlinkNative.CMD_CLOCK_GET, ulinkTimer);  	
    }
    // д��ʱ����
    public void OnClick_bWriteTime(View view)
    {
    	UlinkTimer ulinkTimer = GetUlinkTimer();
    	if (ulinkTimer == null)
    	{
    		return;
    	}
     	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvTimer, UlinkNative.CMD_CLOCK_SET, ulinkTimer);  	
    }
    // ɾ����ʱ����
    public void OnClick_bDelTime(View view)
    {
    	UlinkTimer ulinkTimer = new UlinkTimer();
    	ulinkTimer.currentm 	= 0l;		/* ��ǰʱ�� */	
    	ulinkTimer.mon_unixtm	= 0l;		/* ����һ 00:00��unixʱ��֡*/	
    	ulinkTimer.ulen         = 0;		/* �����������Ϊ0*/
       	ulinkTimer.clk_idx		= (int)ddSaveNumber.getSelectedItemId();		/* ���*/
       	ulinkTimer.uart_idx		= ulinkTimer.clk_idx;		/* c�������*/   
       	ulinkTimer.clkstar		= 0l;		/* ִ��ʱ�� �����ڶ�ʱ��Ϊ�����ʱunix time */
       	ulinkTimer.clkend		= 0l;		/* ��ʱ����ʱ�� */
       	ulinkTimer.clkinv		= 0;		/* ��ʱ��� ֻ��weeks == 0x80 ʱ����Ч*/
       	ulinkTimer.weeks		= 0;			/* ��ʱִ�е�����0x01 mon��0x02 tus ..*/
       	ulinkTimer.cmd			= 0;			/* ����*/
       	ulinkTimer.udata[0] 	= 0;		/* �������� */		
       	vm101Data.ulinkNative.UlinkNative_SendCmd(hRecvTimer, UlinkNative.CMD_CLOCK_DEL, ulinkTimer);  	
    }
    
    // �ܶ�ʱ ʱ�����ÿѡ�񰴼�
    public void OnClick_eZHOU_Time(View view)
    {
    	new TimePickerDialog(timeActivity.this,new OnTimeSetListener() 
    	{
            @Override
            public void onTimeSet(TimePicker view,int hourOfDay,int minute)
           {
            	Show_eZHOU_Time(hourOfDay,minute,0);
           }                
        }, iZHOU_Time_Hour, iZHOU_Time_Minute, true).show();
    }
    // �ζ�ʱ ��ʼʱ�� ���� ѡ�񰴼�
    public void OnClick_eDUAN_Star_Date(View view)
    {    	
    	new DatePickerDialog(timeActivity.this,new OnDateSetListener() 
    	{
            @Override
            public void onDateSet(DatePicker view,int year, int monthOfYear,int dayOfMonth)
           {
            	Show_eDUAN_Star_Data(year,monthOfYear,dayOfMonth);
           }                
        }, iDUAN_Star_Data_Year, iDUAN_Star_Data_Month,  iDUAN_Star_Data_Day).show();
    }
    // �ζ�ʱ ��ʼʱ�� ʱ�� ѡ�񰴼�
    public void OnClick_eDUAN_Star_Time(View view)
    {    	
    	new TimePickerDialog(timeActivity.this,new OnTimeSetListener() 
    	{
            @Override
            public void onTimeSet(TimePicker view,int hourOfDay,int minute)
           {
            	Show_eDUAN_Star_Time(hourOfDay,minute,0);
           }                
        }, iDUAN_Star_Time_Hour, iDUAN_Star_Time_Minute, true).show();
    }
    
    // �ζ�ʱ ����ʱ�� ���� ѡ�񰴼�
    public void OnClick_eDUAN_End_Date(View view)
    {    	
    	new DatePickerDialog(timeActivity.this,new OnDateSetListener() 
    	{
            @Override
            public void onDateSet(DatePicker view,int year, int monthOfYear,int dayOfMonth)
           {
            	Show_eDUAN_End_Data(year,monthOfYear,dayOfMonth);
           }                
        }, iDUAN_End_Data_Year, iDUAN_End_Data_Month,  iDUAN_End_Data_Day).show();
    }
    // �ζ�ʱ ����ʱ�� ʱ�� ѡ�񰴼�
    public void OnClick_eDUAN_End_Time(View view)
    {    	
    	new TimePickerDialog(timeActivity.this,new OnTimeSetListener() 
    	{
            @Override
            public void onTimeSet(TimePicker view,int hourOfDay,int minute)
           {
            	Show_eDUAN_End_Time(hourOfDay,minute,0);
           }                
        }, iDUAN_End_Time_Hour, iDUAN_End_Time_Minute, true).show();
    }
    
    private void SetRadioGroup(int radioNumber)
    {
    	switch (radioNumber)
    	{
    	case 0:		// �ܶ�ʱ
    		eDUAN_Star_Date.setEnabled(false);
    		eDUAN_Star_Time.setEnabled(false);
    		eDUAN_End_Date.setEnabled(false);
    		eDUAN_End_Time.setEnabled(false);
    		eDUAN_Times.setEnabled(false);
    		cbZHOU_1.setEnabled(true);
    		cbZHOU_2.setEnabled(true);
    		cbZHOU_3.setEnabled(true);
    		cbZHOU_4.setEnabled(true);
    		cbZHOU_5.setEnabled(true);
    		cbZHOU_6.setEnabled(true);
    		cbZHOU_7.setEnabled(true);
    		eZHOU_Time.setEnabled(true);
    		radioZHOU.setChecked(true);
    		radioDUAN.setChecked(false);
    		break;
    	case 1:		// �ζ�ʱ
    		eDUAN_Star_Date.setEnabled(true);
    		eDUAN_Star_Time.setEnabled(true);
    		eDUAN_End_Date.setEnabled(true);
    		eDUAN_End_Time.setEnabled(true);
    		eDUAN_Times.setEnabled(true);
    		cbZHOU_1.setEnabled(false);
    		cbZHOU_2.setEnabled(false);
    		cbZHOU_3.setEnabled(false);
    		cbZHOU_4.setEnabled(false);
    		cbZHOU_5.setEnabled(false);
    		cbZHOU_6.setEnabled(false);
    		cbZHOU_7.setEnabled(false);
    		eZHOU_Time.setEnabled(false);
    		radioZHOU.setChecked(false);
    		radioDUAN.setChecked(true);
    		break;
    	case 2:		//�����ʹ�������
    		eUART_Buff.setEnabled(true);
    		ddPinNumber.setEnabled(false);
    		ddPinLevel.setEnabled(false);
    		radioGPIO.setChecked(false);
    		radioUART.setChecked(true);
    		break;
    	case 3:		// GPIO����
    		eUART_Buff.setEnabled(false);
    		ddPinNumber.setEnabled(true);
    		ddPinLevel.setEnabled(true);
    		radioGPIO.setChecked(true);
    		radioUART.setChecked(false);
    		break;
		default:	// ������
    		radioDUAN.setChecked(false);
    		radioZHOU.setChecked(false);
    		radioGPIO.setChecked(false);
      		radioUART.setChecked(false);      	     		   
			break;
    	}
    }
    private void ShowMessage(String sMess)
    {
    	new  AlertDialog.Builder(this)    
    	   
    	                .setTitle("Message" )  
    	   
    	                .setMessage(sMess )  
    	   
    	                .setPositiveButton("ȷ��" ,  null )  
    	   
    	                .show(); 
    }
	
	   
    private void Show_eZHOU_Time(int hourOfDay,int minute,int second)
    {
    	iZHOU_Time_Hour   = hourOfDay;// �ܶ�ʱ��ʱ
    	iZHOU_Time_Minute = minute;	  // �ܶ�ʱ����
    	iZHOU_Time_Second = second;	  // �ܶ�ʱ����
      	
        String stmp = String.format("%02d:%02d:%02d", hourOfDay,minute,second);                
        eZHOU_Time.setText(stmp);   	
    }
    private void Show_eDUAN_Star_Data(int year, int monthOfYear,int dayOfMonth)
    {
    	iDUAN_Star_Data_Year  = year;		// �ζ�ʱ����ʼʱ�䣬��
    	iDUAN_Star_Data_Month = monthOfYear;// �ζ�ʱ����ʼʱ�䣬��
    	iDUAN_Star_Data_Day   = dayOfMonth;	// �ζ�ʱ����ʼʱ�䣬��	
    	
    	String stmp2 = String.format("%04d-%02d-%02d", year,monthOfYear+1,dayOfMonth);                
        eDUAN_Star_Date.setText(stmp2);   	
    }
    private void Show_eDUAN_Star_Time(int hourOfDay,int minute,int second)
    {
    	iDUAN_Star_Time_Hour   = hourOfDay;	// �ζ�ʱ����ʼʱ�䣬ʱ
    	iDUAN_Star_Time_Minute = minute;	// �ζ�ʱ����ʼʱ�䣬��
    	iDUAN_Star_Time_Second = second;	// �ζ�ʱ����ʼʱ�䣬��
    	
    	String stmp = String.format("%02d:%02d:%02d", hourOfDay,minute,second);                
        eDUAN_Star_Time.setText(stmp);   	
    }

    private void Show_eDUAN_End_Data(int year, int monthOfYear,int dayOfMonth)
    {
    	iDUAN_End_Data_Year  = year;		// �ζ�ʱ������ʱ�䣬��
    	iDUAN_End_Data_Month = monthOfYear;	// �ζ�ʱ������ʱ�䣬��
    	iDUAN_End_Data_Day   = dayOfMonth;	// �ζ�ʱ������ʱ�䣬��	

    	String stmp2 = String.format("%04d-%02d-%02d", year,monthOfYear+1,dayOfMonth);                
        eDUAN_End_Date.setText(stmp2);   	
   }
    private void Show_eDUAN_End_Time(int hourOfDay,int minute,int second)
    {
    	iDUAN_End_Time_Hour   = hourOfDay;	// �ζ�ʱ������ʱ�䣬ʱ
    	iDUAN_End_Time_Minute = minute;		// �ζ�ʱ������ʱ�䣬��
    	iDUAN_End_Time_Second = second;		// �ζ�ʱ������ʱ�䣬��

       	String stmp = String.format("%02d:%02d:%02d", hourOfDay,minute,second);                
        eDUAN_End_Time.setText(stmp);   	
    }
    
    private Date UnixtmToDate(long unixtm)
    {
		String stmp4 = ""+unixtm;
		Long timestamp = Long.parseLong(stmp4)*1000;    
		Date date =new Date(timestamp);
		return date;
    }
    private long DateToUnixtm(int year, int monthOfYear,int dayOfMonth,int hourOfDay,int minute,int second)
    {
		Date date =new Date();
		date.setYear(year-1900);
		date.setMonth(monthOfYear);
		date.setDate(dayOfMonth);
		date.setHours(hourOfDay);
		date.setMinutes(minute);
		date.setSeconds(second);	
		Long ltmp = date.getTime(); 
		Long timestamp = ltmp/1000;   
		return timestamp;
    }
    
    private void ShowWeeks(int weeks)
    {

		cbZHOU_1.setChecked(false);
		cbZHOU_2.setChecked(false);
		cbZHOU_3.setChecked(false);
		cbZHOU_4.setChecked(false);
		cbZHOU_5.setChecked(false);
		cbZHOU_6.setChecked(false);
		cbZHOU_7.setChecked(false);

    	
    	if ( (weeks&WEEK_1) == WEEK_1 )// ��һ
    	{
    		cbZHOU_1.setChecked(true);
    	}
    		
    	if ( (weeks&WEEK_2) == WEEK_2 )// �ܶ�
    	{
    		cbZHOU_2.setChecked(true);
    	}
    	if ( (weeks&WEEK_3) == WEEK_3 )// ����
    	{
    		cbZHOU_3.setChecked(true);
    	}
    	if ( (weeks&WEEK_4) == WEEK_4 )// ����
    	{
    		cbZHOU_4.setChecked(true);
    	}
    	if ( (weeks&WEEK_5) == WEEK_5 )// ����
    	{
    		cbZHOU_5.setChecked(true);
    	}
    	if ( (weeks&WEEK_6) == WEEK_6 )// ����
    	{
    		cbZHOU_6.setChecked(true);
    	}
    	if ( (weeks&WEEK_7) == WEEK_7 )// ����
    	{
    		cbZHOU_7.setChecked(true);
    	}
    	
    }
    private int GetWeeks()
    {
    	int ret = 0;
			
    	if ( cbZHOU_1.isChecked() == true )// ��һ
    	{
    		ret |= WEEK_1;
    	}   		
    	if ( cbZHOU_2.isChecked() == true )// �ܶ�
    	{
    		ret |= WEEK_2;
    	}
    	if ( cbZHOU_3.isChecked() == true )// ����
    	{
    		ret |= WEEK_3;
    	}
    	if ( cbZHOU_4.isChecked() == true )// ����
    	{
    		ret |= WEEK_4;
    	}
    	if ( cbZHOU_5.isChecked() == true )// ����
    	{
    		ret |= WEEK_5;
    	}
    	if ( cbZHOU_6.isChecked() == true )// ����
    	{
    		ret |= WEEK_6;
    	}
    	if ( cbZHOU_7.isChecked() == true )// ����
    	{
    		ret |= WEEK_7;
    	}
    	return ret;
    }
    private void ShowUlinkTimer(UlinkTimer uTimer)
    {
    	if ( uTimer.cmd == 0 || uTimer.clkend<600000000)	// �ն�ʱ����
    	{
    		SetRadioGroup(0xff);
    		ShowMessage("�޶�ʱ����");
    		return;
    	}
    	
    	// �ܶ�ʱ ���� �����ʱ
		if ( uTimer.weeks == 0x80 )	// �����ʱ
		{
			SetRadioGroup(1);
			// ��ʾ��ʼʱ��
			Date dtmp1 = UnixtmToDate(uTimer.clkstar);
			Show_eDUAN_Star_Data((int)dtmp1.getYear()+1990,(int)dtmp1.getMonth(),(int)dtmp1.getDay());
			Show_eDUAN_Star_Time((int)dtmp1.getHours(),(int)dtmp1.getMinutes(),(int)dtmp1.getSeconds());
			// ��ʾ����ʱ��
			Date dtmp2 = UnixtmToDate(uTimer.clkend);
			Show_eDUAN_End_Data((int)dtmp2.getYear()+1990,(int)dtmp2.getMonth(),(int)dtmp2.getDay());
			Show_eDUAN_End_Time((int)dtmp2.getHours(),(int)dtmp2.getMinutes(),(int)dtmp2.getSeconds());
			// ��ʾ��ʱʱ��
			String stmp = ""+uTimer.clkinv;
			eDUAN_Times.setText(stmp);
		}
		else 						// �ܶ�ʱ
		{
			SetRadioGroup(0);
			// ��ʾ��ʼʱ��
			Date dtmp = UnixtmToDate(uTimer.clkstar);
			Show_eZHOU_Time((int)dtmp.getHours(),(int)dtmp.getMinutes(),(int)dtmp.getSeconds());
			// ��ʾ���趨
			ShowWeeks(uTimer.weeks);
		}
		
		// �������� ���� GPIO����
		if ( uTimer.cmd == UlinkNative.CMD_TM_UARTSEND )
		{
			SetRadioGroup(2);
			// �����ת��
    		String str="";  
    		try 
        	{  
				str = new String(uTimer.udata,0,uTimer.ulen,"GBK");	
	    	} 
        	catch (UnsupportedEncodingException e) 
        	{  
                e.printStackTrace();  
            }  
    		eUART_Buff.setText(str);			
		}
		else
		{
			SetRadioGroup(3);
			int m_pin_cmd    = uTimer.cmd&0x01;			// ON=1 ���� OFF=0
			int m_pin_number = ((uTimer.cmd>>4)&0x0F)-1;
			ddPinNumber.setSelection(m_pin_number);
			ddPinLevel.setSelection(m_pin_cmd);
		}
		
    }
    private UlinkTimer GetUlinkTimer()
    {    	
    	UlinkTimer uTimer = new UlinkTimer();
    	
    	
    	// �ܶ�ʱ ���� �����ʱ
		if ( radioZHOU.isChecked() == true )	// �ܶ�ʱ
		{
			uTimer.clkstar = DateToUnixtm(1990,0,1,iZHOU_Time_Hour,iZHOU_Time_Minute,iZHOU_Time_Second);
			uTimer.clkend  = DateToUnixtm(2115,0,1,iZHOU_Time_Hour,iZHOU_Time_Minute,iZHOU_Time_Second);
			uTimer.clkinv  = 0;
			uTimer.weeks   = GetWeeks();
			if ( uTimer.weeks == 0 )
			{
				ShowMessage("��ѡ������");
	    		return null;
			}
    	}
		else if ( radioDUAN.isChecked() == true )	// �����ʱ 						// 
		{
			uTimer.clkstar = DateToUnixtm(iDUAN_Star_Data_Year,iDUAN_Star_Data_Month,iDUAN_Star_Data_Day,iDUAN_Star_Time_Hour,iDUAN_Star_Time_Minute,iDUAN_Star_Time_Second);
			uTimer.clkend  = DateToUnixtm(iDUAN_End_Data_Year,iDUAN_End_Data_Month,iDUAN_End_Data_Day,iDUAN_End_Time_Hour,iDUAN_End_Time_Minute,iDUAN_End_Time_Second);
			uTimer.clkinv  = 0;
			String stmp = eDUAN_Times.getText().toString();
			if ( stmp.length() > 0 )
			{
				uTimer.clkinv = Integer.parseInt(stmp);
			}
			uTimer.weeks   = 0x80;
			if ( uTimer.clkinv == 0 )
			{
				ShowMessage("��������ȷ�Ķ�ʱʱ��");
	    		return null;
			}
		}
		else 
		{
			ShowMessage("��ѡ��ʱ����");
    		return null;
		}
		
		
		// �������� ���� GPIO����
		if ( radioUART.isChecked() == true )      //��������
		{
			uTimer.cmd = UlinkNative.CMD_TM_UARTSEND;
			
			// ��������
			String stmp = eUART_Buff.getText().toString();
    		try {
				byte[]btmp   = stmp.getBytes("GBK");
				uTimer.ulen  = btmp.length;
				uTimer.udata = btmp.clone();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    		

		}
		else if ( radioGPIO.isChecked() == true ) //GPIO����
		{
			int iNumber = (int)ddPinNumber.getSelectedItemId()+1;
			int iLevel  = (int)ddPinLevel.getSelectedItemId();			
			uTimer.cmd  = (int)((iNumber<<4)|iLevel);
			uTimer.ulen = 0;
		}
		else
		{
			ShowMessage("��ѡ��ʱ����");
			return null;
		}
		
		// �洢λ��
		uTimer.uart_idx = (int)ddSaveNumber.getSelectedItemId();
		uTimer.clk_idx  = uTimer.uart_idx;
		
		uTimer.currentm   = DateToUnixtm(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH),c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),c.get(Calendar.SECOND));
		uTimer.mon_unixtm = 631123200;// �й�ʱ����1990-1-1,0:0:0����һʱ��ֵ��

		return uTimer;
    }
}
