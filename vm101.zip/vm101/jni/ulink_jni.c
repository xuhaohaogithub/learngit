/*******************************************************************************

 This file is part of the project.
 Copyright vlinks.cn.
 All right reserved.

 File:    ulink_jni.c

 No description

 TIME LIST:
 CREATE  lanny   2014-09-09 09:26:57

 *******************************************************************************/

#include <jni.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <android/log.h>
#include "ulink.h"

#define   LOG_TAG    "VLINKS"
#define   LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define   LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

jstring strToJstring(JNIEnv* env, const char* pStr)
{
	int strLen = strlen(pStr);
	jclass jstrObj = (*env)->FindClass(env, "java/lang/String");
	jmethodID methodId = (*env)->GetMethodID(env, jstrObj, "<init>",
			"([BLjava/lang/String;)V");
	jbyteArray byteArray = (*env)->NewByteArray(env, strLen);
	jstring encode = (*env)->NewStringUTF(env, "utf-8");

	(*env)->SetByteArrayRegion(env, byteArray, 0, strLen, (jbyte*) pStr);

	return (jstring)(*env)->NewObject(env, jstrObj, methodId, byteArray, encode);
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkInit(JNIEnv *pjEnv, jclass clazz,
		jstring host, jstring app_id) {
	const char* devid = (*pjEnv)->GetStringUTFChars(pjEnv, host, NULL);
	const char* appid = (*pjEnv)->GetStringUTFChars(pjEnv, app_id, NULL);
	ulink_debug(1);
	return ulink_init(devid, appid);
}
jint JNICALL Java_com_ulink_UlinkNative_ulinkDeinit(JNIEnv *pjEnv, jclass clazz) {
	return ulink_deinit();
}

jint JNICALL Java_com_ulink_UlinkNative_smlinkStart(JNIEnv *pjEnv, jclass clazz,
		jstring sSsid, jstring sPassword) {
	const char* pSsid     = (*pjEnv)->GetStringUTFChars(pjEnv, sSsid, NULL);
	const char* pPassword = (*pjEnv)->GetStringUTFChars(pjEnv, sPassword, NULL);

	return smlink_start(pSsid, pPassword);
}
jint JNICALL Java_com_ulink_UlinkNative_smlinkStop(JNIEnv *pjEnv, jclass clazz) {
	return smlink_stop();
}
jint JNICALL Java_com_ulink_UlinkNative_pidListInit(JNIEnv *pjEnv, jclass clazz) {
	return pid_list_init();
}
jint JNICALL Java_com_ulink_UlinkNative_pidScan(JNIEnv *pjEnv, jclass clazz) {
	return pid_scan();
}
JNIEXPORT jobject JNICALL Java_com_ulink_UlinkNative_readPidList(JNIEnv * pjEnv, jobject obj, jint maxLen)
{
	int i, lenlist;
	UP2P_PID_DEV plist[maxLen];
	lenlist = pid_list_read(&plist[0], maxLen);
	if (lenlist <= 0)
	{
		return NULL;
	}
	//���ArrayList������
	jclass list_cls = (*pjEnv)->FindClass(pjEnv, "java/util/ArrayList");
	if(list_cls == NULL)
	{
		return NULL;
	}
	//��õù��캯��Id
	jmethodID list_costruct = (*pjEnv)->GetMethodID(pjEnv, list_cls , "<init>","()V");
	//����һ��Arraylist���϶���
	jobject list_obj = (*pjEnv)->NewObject(pjEnv, list_cls , list_costruct);
	//���Arraylist���е� add()����ID���䷽��ԭ��Ϊ�� boolean add(Object object) ;
	jmethodID list_add  = (*pjEnv)->GetMethodID(pjEnv, list_cls,"add","(Ljava/lang/Object;)Z");
	jclass devcls = (*pjEnv)->FindClass(pjEnv, "com/ulink/UlinkPidDev");
	//��ø����͵Ĺ��캯��  ������Ϊ <init> �������ͱ���Ϊ void �� V
	jmethodID dev_costruct = (*pjEnv)->GetMethodID(pjEnv, devcls , "<init>", "(IIIII)V");
	for(i = 0 ; i < lenlist ; i++)
	{
		//����һ������
		jobject dev_obj = (*pjEnv)->NewObject(pjEnv, devcls , dev_costruct , plist[i].pid0, plist[i].pid1, plist[i].dev0, plist[i].dev1, plist[i].keytype);
		//ִ��Arraylist��ʵ����add����������һ��stu����
		(*pjEnv)->CallBooleanMethod(pjEnv, list_obj , list_add , dev_obj);
	}
	return list_obj ;
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkOnlyConfig(JNIEnv *pjEnv, jclass clazz,jstring dev_id,jbyteArray outkey)
{
	const char* devid = (*pjEnv)->GetStringUTFChars(pjEnv, dev_id, NULL);
	char* pOutKey = (*pjEnv)->GetPrimitiveArrayCritical(pjEnv, outkey, 0);
	int ret = ulink_only_config(devid, pOutKey);
	(*pjEnv)->ReleasePrimitiveArrayCritical(pjEnv, outkey, pOutKey, 0);
	return ret;
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkOpen(JNIEnv *pjEnv, jclass clazz,jstring dev_id, jstring u_key)
{
	const char* devid = (*pjEnv)->GetStringUTFChars(pjEnv, dev_id, NULL);
	const char* ukey = (*pjEnv)->GetStringUTFChars(pjEnv, u_key, NULL);
	int * ulink = (int *) ulink_open(devid, ukey);
	return (int) ulink;
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkClose(JNIEnv *pjEnv, jclass clazz,jint link)
{
	return ulink_close((struct ULINK *)link);
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkSendCmd(JNIEnv *pjEnv,jclass clazz, jint link, jint cmd, jbyteArray param, jint len)
{
	int ret;
//	if( link == 0 ) return -1;	// �жϲ����Ƿ�Ϸ�

	jbyte *jbarray = (jbyte *) malloc(len * sizeof(jbyte));
	(*pjEnv)->GetByteArrayRegion(pjEnv,param, 0, len, jbarray);
	jbyte *dDate = (jbyte*) jbarray;
	ret = ulink_cmd_send((struct ULINK *)link, cmd, dDate, len);
	return ret;
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkWaitCmd(JNIEnv *pjEnv,jclass clazz, jint link, jint cmd, jbyteArray param, int maxlen)
{
	char* pBuf;
	int len;

//	if( link == 0 ) return -1;	// �жϲ����Ƿ�Ϸ�

	pBuf = (*pjEnv)->GetPrimitiveArrayCritical(pjEnv, param, 0);
	len = ulink_cmd_wait((struct ULINK *)link, cmd, pBuf, maxlen);
	(*pjEnv)->ReleasePrimitiveArrayCritical(pjEnv, param, pBuf, 0);
	return len;
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkSendGPIOCmd(JNIEnv *pjEnv,jclass clazz, jint link, jint cmd, jobject customer)
{
//	if(link == 0) return -1;


	jclass cls_objClass = (*pjEnv)->GetObjectClass(pjEnv, customer);
	jfieldID pinId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "pin", "I");
	jfieldID modeId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "mode", "I");
	jfieldID valueId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "value", "I");
	jint pin = (*pjEnv)->GetIntField(pjEnv, customer, pinId);
	jint mode = (*pjEnv)->GetIntField(pjEnv, customer, modeId);
	jint value = (*pjEnv)->GetIntField(pjEnv, customer, valueId);
	UP2P_GPIO pgpio_cust;
	pgpio_cust.pin = pin;
	pgpio_cust.mode = mode;
	pgpio_cust.value = value;
	return ulink_cmd_send((struct ULINK *)link, cmd, (char*) &pgpio_cust,sizeof(UP2P_GPIO));
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkWaitGPIOCmd(JNIEnv *pjEnv,jclass clazz, jint link, jint cmd, jobject customer)
{
	int ret = 0;
//	if(link == 0) return -1;


	jclass cls_objClass = (*pjEnv)->GetObjectClass(pjEnv, customer);
	jfieldID pinId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "pin", "I");
	jfieldID modeId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "mode", "I");
	jfieldID valueId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "value", "I");
	UP2P_GPIO rec_buf;
	ret = ulink_cmd_wait((struct ULINK *)link, cmd, (char *) &rec_buf,sizeof(UP2P_GPIO));
	if ( ret >= 3 )
	{
		(*pjEnv)->SetIntField(pjEnv, customer, pinId, rec_buf.pin);
		(*pjEnv)->SetIntField(pjEnv, customer, modeId, rec_buf.mode);
		(*pjEnv)->SetIntField(pjEnv, customer, valueId, rec_buf.value);
	}
	return ret;
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkSendClockCmd(JNIEnv *pjEnv,jclass clazz, jint link, jint cmd, jobject customer)
{
	//if(link == 0)return -1;


	jclass cls_objClass = (*pjEnv)->GetObjectClass(pjEnv, customer);
	jfieldID currentmId   = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "currentm", "J");	/* ��ǰʱ�� */
	jfieldID mon_unixtmId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "mon_unixtm", "J");	/* ����һ 00:00��unixʱ��֡*/
	jfieldID clkstarId    = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clkstar", "J");	/* ִ��ʱ�� �����ڶ�ʱ��Ϊ�����ʱunix time */
	jfieldID clkendId     = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clkend", "J");		/* ��ʱ����ʱ�� */
	jfieldID clkinvId     = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clkinv", "I");		/* ��ʱ��� ֻ��weeks == 0x80 ʱ����Ч*/
	jfieldID weeksId      = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "weeks", "I");		/* ��ʱִ�е�����0x01 mon��0x02 tus ..*/
	jfieldID clock_cmdId  = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "cmd", "I");			/* ����*/
	jfieldID clk_idxId    = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clk_idx", "I");		/* ���*/
	jfieldID uart_idxId   = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "uart_idx", "I");		/* c�������*/
	jfieldID ulenId       = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "ulen", "I");			/* u�������ݳ���*/
	jfieldID udataId      = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "udata", "[B");		/* �������� */
	jlong currentm   = (*pjEnv)->GetLongField(pjEnv, customer, currentmId);		/* ��ǰʱ�� */
	jlong mon_unixtm = (*pjEnv)->GetLongField(pjEnv, customer, mon_unixtmId);	/* ����һ 00:00��unixʱ��֡*/
	jlong clkstar    = (*pjEnv)->GetLongField(pjEnv, customer, clkstarId);		/* ִ��ʱ�� �����ڶ�ʱ��Ϊ�����ʱunix time */
	jlong clkend     = (*pjEnv)->GetLongField(pjEnv, customer, clkendId);		/* ��ʱ����ʱ�� */
	jint clkinv     = (*pjEnv)->GetIntField(pjEnv, customer, clkinvId);		/* ��ʱ��� ֻ��weeks == 0x80 ʱ����Ч*/
	jint weeks      = (*pjEnv)->GetIntField(pjEnv, customer, weeksId);		/* ��ʱִ�е�����0x01 mon��0x02 tus ..*/
	jint clock_cmd  = (*pjEnv)->GetIntField(pjEnv, customer, clock_cmdId);	/* ����*/
	jint clk_idx    = (*pjEnv)->GetIntField(pjEnv, customer, clk_idxId);	/* ���*/
	jint uart_idx   = (*pjEnv)->GetIntField(pjEnv, customer, uart_idxId);	/* c�������*/
	jint ulen       = (*pjEnv)->GetIntField(pjEnv, customer, ulenId);		/* u�������ݳ���*/
	jbyteArray data_arry      = (jbyteArray)((*pjEnv)->GetObjectField(pjEnv, customer, udataId));		/* �������� */
	jbyte * pdata_arry = (*pjEnv)->GetByteArrayElements(pjEnv, data_arry, 0);


	u8 buf[255];
	int i;
	settimepacke_st *apptm= (settimepacke_st *)buf;
	apptm->currentm			= currentm;
	apptm->mon_unixtm		= mon_unixtm;
	apptm->settm.clkstar	= clkstar;
	apptm->settm.clkend		= clkend;
	apptm->settm.clkinv		= clkinv;
	apptm->settm.weeks		= weeks;
	apptm->settm.cmd		= clock_cmd;
	apptm->settm.clk_idx	= clk_idx;
	apptm->settm.uart_idx	= uart_idx;
	apptm->settm.ulen		= ulen;
	for (i=0; i<ulen; i++)
	{
		apptm->settm.udata[i] = pdata_arry[i];
	}
	apptm->settm.udata[i] = 0x00;

	return ulink_cmd_send((struct ULINK *)link, cmd, (char*) apptm,sizeof(settimepacke_st)+ulen);
}
jint JNICALL Java_com_ulink_UlinkNative_ulinkWaitClockCmd(JNIEnv *pjEnv,jclass clazz, jint link, jint cmd, jobject customer)
{
	int ret = 0;
//	if(link == 0) return -1;

	jclass cls_objClass   = (*pjEnv)->GetObjectClass(pjEnv, customer);
	jfieldID currentmId   = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "currentm", "J");		/* ��ǰʱ�� */
	jfieldID mon_unixtmId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "mon_unixtm", "J");	/* ����һ 00:00��unixʱ��֡*/
	jfieldID clkstarId    = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clkstar", "J");		/* ִ��ʱ�� �����ڶ�ʱ��Ϊ�����ʱunix time */
	jfieldID clkendId     = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clkend", "J");		/* ��ʱ����ʱ�� */
	jfieldID clkinvId     = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clkinv", "I");		/* ��ʱ��� ֻ��weeks == 0x80 ʱ����Ч*/
	jfieldID weeksId      = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "weeks", "I");		/* ��ʱִ�е�����0x01 mon��0x02 tus ..*/
	jfieldID clock_cmdId  = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "cmd", "I");			/* ����*/
	jfieldID clk_idxId    = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clk_idx", "I");		/* ���*/
	jfieldID uart_idxId   = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "uart_idx", "I");		/* c�������*/
	jfieldID ulenId       = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "ulen", "I");			/* u�������ݳ���*/
	jfieldID udataId      = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "udata", "[B");		/* �������� */

	u8 buf[255];
	int i;
	memset(buf,0,sizeof(buf));
	settimepacke_st *apptm= (settimepacke_st *)buf;
	ret = ulink_cmd_wait((struct ULINK *)link, cmd, (char *) &apptm->settm,sizeof(timestamp_st)+33);
	if ( ret > 0 )
	{
		(*pjEnv)->SetLongField(pjEnv, customer, currentmId, 0);
		(*pjEnv)->SetLongField(pjEnv, customer, mon_unixtmId, 0);
		(*pjEnv)->SetLongField(pjEnv, customer, clkstarId, apptm->settm.clkstar);
		(*pjEnv)->SetLongField(pjEnv, customer, clkendId, apptm->settm.clkend);
		(*pjEnv)->SetIntField(pjEnv, customer, clkinvId, apptm->settm.clkinv);
		(*pjEnv)->SetIntField(pjEnv, customer, weeksId, apptm->settm.weeks);
		(*pjEnv)->SetIntField(pjEnv, customer, clock_cmdId, apptm->settm.cmd);
		(*pjEnv)->SetIntField(pjEnv, customer, clk_idxId, apptm->settm.clk_idx);
		(*pjEnv)->SetIntField(pjEnv, customer, uart_idxId, apptm->settm.uart_idx);
		(*pjEnv)->SetIntField(pjEnv, customer, ulenId, apptm->settm.ulen);

		//��BYTE����תΪjarray
		jbyte* byte = (jbyte*)&apptm->settm.udata[0];
		jbyteArray jarray = (*pjEnv)->NewByteArray(pjEnv,32);
		(*pjEnv)->SetByteArrayRegion(pjEnv,jarray, 0, apptm->settm.ulen,byte);
		//��ÿһ��ʵ���ı�����ֵ
		(*pjEnv)->SetObjectField(pjEnv,customer,udataId,jarray);

	}
	return ret;
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkUpgrade(JNIEnv *pjEnv,jclass clazz, jint link, jbyteArray param, jint len)
{
	int ret;
	//if( link == 0 ) return -1;	// �жϲ����Ƿ�Ϸ�

	jbyte *jbarray = (jbyte *) malloc(len * sizeof(jbyte));
	(*pjEnv)->GetByteArrayRegion(pjEnv,param, 0, len, jbarray);
	jbyte *dDate = (jbyte*) jbarray;
	ret = ulink_update_vm10x((struct ULINK *)link, dDate, len);
	return ret;
}
jint JNICALL Java_com_ulink_UlinkNative_ulinkOnekeyConfig(JNIEnv *pjEnv,jclass clazz, jobject customer)
{
	int ret;

	jclass cls_objClass = (*pjEnv)->GetObjectClass(pjEnv, customer);
	LOGI("Java_com_ulink_UlinkNative_ulinkOnekeyConfig");
	jfieldID uPidId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "uPid", "[B");			/* pid */
	jbyteArray aPid = (jbyteArray)((*pjEnv)->GetObjectField(pjEnv, customer, uPidId));	/* pid */
	jbyte * pPid    = (*pjEnv)->GetByteArrayElements(pjEnv, aPid, 0);
	LOGI("pid=%s",pPid);

	jfieldID uSsidId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "uSsid", "[B");			/* ssid */
	jbyteArray aSsid = (jbyteArray)((*pjEnv)->GetObjectField(pjEnv, customer, uSsidId));	/* ssid */
	jbyte * pSsid    = (*pjEnv)->GetByteArrayElements(pjEnv, aSsid, 0);
	LOGI("ssid");

	jfieldID uPswId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "uPsw", "[B");			/* PswId */
	jbyteArray aPsw = (jbyteArray)((*pjEnv)->GetObjectField(pjEnv, customer, uPswId));	/* PswId */
	jbyte * pPsw    = (*pjEnv)->GetByteArrayElements(pjEnv, aPsw, 0);
	LOGI("PswId");

	jfieldID uOutDevId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "uOutDev", "[B");			/* uOutDev */
	jbyteArray aOutDev = (jbyteArray)((*pjEnv)->GetObjectField(pjEnv, customer, uOutDevId));	/* uOutDev */
	jbyte * pOutDev    = (*pjEnv)->GetByteArrayElements(pjEnv, aOutDev, 0);
	LOGI("uOutDev");

	jfieldID uOutKeyId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "uOutKey", "[B");			/* uOutKey */
	jbyteArray aOutKey = (jbyteArray)((*pjEnv)->GetObjectField(pjEnv, customer, uOutKeyId));	/* uOutKey */
	jbyte * pOutKey    = (*pjEnv)->GetByteArrayElements(pjEnv, aOutKey, 0);
	LOGI("uOutKey");

	jfieldID typeId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "type", "I");	/* ��������*/
	jint itype      = (*pjEnv)->GetIntField(pjEnv, customer, typeId);			/* ��������*/
	LOGI("type");

	ret = ulink_onekey_config(pPid, pSsid, pPsw, itype, pOutDev, pOutKey);
	LOGI("ret=%d",ret);
	if (ret == 0 )
	{
		// ����OutDev
		jbyteArray jOutDev = (*pjEnv)->NewByteArray(pjEnv,16);
		(*pjEnv)->SetByteArrayRegion(pjEnv,jOutDev, 0, 16,pOutDev);
		(*pjEnv)->SetObjectField(pjEnv,customer,uOutDevId,jOutDev);
		LOGI("OutDev");

		// ����OutKey
		jbyteArray jOutKey = (*pjEnv)->NewByteArray(pjEnv,16);
		(*pjEnv)->SetByteArrayRegion(pjEnv,jOutKey, 0, 16,pOutKey);
		(*pjEnv)->SetObjectField(pjEnv,customer,uOutKeyId,jOutKey);
		LOGI("OutKey");
	}
	return ret;
}

#if 0


jstring Java_com_ulink_UlinkNative_ulinkConfig(JNIEnv *pjEnv, jclass clazz,
		jstring dev_id, jstring ss_id, jstring pass_wd, jint type,
		jstring keystr) {
	const char* devid = (*pjEnv)->GetStringUTFChars(pjEnv, dev_id, NULL);
	const char* ssid = (*pjEnv)->GetStringUTFChars(pjEnv, ss_id, NULL);
	const char* passwd = (*pjEnv)->GetStringUTFChars(pjEnv, pass_wd, NULL);
	char str_key_buf[32] = { 0 };
	memset(str_key_buf, 0, 32);

	jint ret = ulink_config(devid, ssid, passwd, type, str_key_buf);

//	jclass strClass = (*pjEnv)->FindClass(pjEnv, "java/lang/String");
//	jmethodID ctorID = (*pjEnv)->GetMethodID(pjEnv, strClass, "<init>","([BLjava/lang/String;)V");
//	jbyteArray bytes_key = (*pjEnv)->NewByteArray(pjEnv, 16);
//	(*pjEnv)->SetByteArrayRegion(pjEnv, bytes_key, 0, 16, (jbyte*) &str_key_buf);
//	jstring encoding = (*pjEnv)->NewStringUTF(pjEnv, "utf-8");
//	jstring outstr = (jstring)(*pjEnv)->NewObject(pjEnv, strClass, ctorID,bytes_key, encoding);
//	jmethodID ctorID2 = (*pjEnv)->GetMethodID(pjEnv, strClass, "<init>","(Ljava/lang/String;)V");
//	LOGI("ulinkConfig before CallVoidMethod");
//	(*pjEnv)->CallVoidMethod(pjEnv, keystr, ctorID2, outstr);
//	LOGI("ulinkConfig after CallVoidMethod");
	return strToJstring(pjEnv,str_key_buf);
//	return ret;

}

jint Java_com_ulink_UlinkNative_ulinkSendOnline(JNIEnv *pjEnv, jclass clazz,
		jint link) {
	if(link <= 0){
		return -1;
	}else{
		return ulink_send_online((ULINK *) link);
	}
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkCheckOnline(JNIEnv *pjEnv,
		jclass clazz, jint link) {
	if(link <= 0){
		return -1;
	}else{
		return ulink_check_online((ULINK *) link);
	}
}




jint JNICALL Java_com_ulink_UlinkNative_ulinkSendPWMCmd(JNIEnv *pjEnv,
		jclass clazz, jint link, jint cmd, jobject customer) {
	if(link <= 0){
		return -1;
	}
	jclass cls_objClass = (*pjEnv)->GetObjectClass(pjEnv, customer);
	jfieldID pinId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "pin", "I");
	jfieldID timer_cntId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass,
			"timer_cnt", "I");
	jfieldID dutyId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "duty", "I");
	jfieldID freqId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "freq", "I");

	jint pin = (jint)(*pjEnv)->GetIntField(pjEnv, customer, pinId);
	jint timer_cnt = (jint)(*pjEnv)->GetIntField(pjEnv, customer, timer_cntId);
	jint duty = (jint)(*pjEnv)->GetIntField(pjEnv, customer, dutyId);
	jint freq = (jint)(*pjEnv)->GetIntField(pjEnv, customer, freqId);

	pwm_cust_ ppwm_cust;
	ppwm_cust.pin = pin;
	ppwm_cust.timer_cnt = timer_cnt;
	ppwm_cust.duty = duty;
	ppwm_cust.freq = freq;
	return ulink_cmd_send((ULINK *) link, cmd, (char*) &ppwm_cust,
			sizeof(pwm_cust_));
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkSendI2CCmd(JNIEnv *pjEnv,
		jclass clazz, jint link, jint cmd, jobject customer) {
	if(link <= 0){
		return -1;
	}
	jclass cls_objClass = (*pjEnv)->GetObjectClass(pjEnv, customer);
	jfieldID clk_pin_id = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clk_pin",
			"I");
	jfieldID sda_pin_id = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "sda_pin",
			"I");
	jfieldID speed_id = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "speed", "I");
	jfieldID address_id = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "address",
			"I");
	jfieldID w_len_id = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "w_len", "I");
	jfieldID r_len_id = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "r_len", "I");
	jfieldID date_id = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "date", "[B");

	jint clkPin = (jint)(*pjEnv)->GetIntField(pjEnv, customer, clk_pin_id);
	jint sdaPin = (jint)(*pjEnv)->GetIntField(pjEnv, customer, sda_pin_id);
	jint speed = (jint)(*pjEnv)->GetIntField(pjEnv, customer, speed_id);
	jint address = (jint)(*pjEnv)->GetIntField(pjEnv, customer, address_id);
	jint wLen = (jint)(*pjEnv)->GetIntField(pjEnv, customer, w_len_id);
	jint rLen = (jint)(*pjEnv)->GetIntField(pjEnv, customer, r_len_id);
	jbyteArray value = (jbyteArray)(*pjEnv)->GetObjectField(pjEnv, customer,
			date_id);
	jbyte *dat = (*pjEnv)->GetByteArrayElements(pjEnv, value, 0);
	I2C_cust_ iic_cust;
	iic_cust.clk_pin = clkPin;
	iic_cust.sda_pin = sdaPin;
	iic_cust.speed = speed;
	iic_cust.address = address;
	iic_cust.w_len = wLen;
	iic_cust.r_len = rLen;
	int i = 0;
	if (CMD_I2C_WRITE == cmd) {
		for (i = 0; i < wLen; i++) {
			iic_cust.date[i] = dat[i];
		}
	} else if (CMD_I2C_READ == cmd) {
		for (i = 0; i < rLen; i++) {
			iic_cust.date[i] = dat[i];
		}
	}
	return ulink_cmd_send((ULINK *) link, cmd, (char*) &iic_cust,
			sizeof(I2C_cust_) + wLen);
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkUpdateWifiUdpSend(JNIEnv *pjEnv,
		jclass clazz, jint link, jbyteArray param, jint len) {
	if(link <= 0){
		return -1;
	}
	jbyte *update_buf = (*pjEnv)->GetByteArrayElements(pjEnv, param, 0);
	return ulink_update_vm10x((ULINK *) link, update_buf, len);
}


jint JNICALL Java_com_ulink_UlinkNative_ulinkWaitPWMCmd(JNIEnv *pjEnv,
		jclass clazz, jint link, jint cmd, jobject customer) {
	int ret = 0;
	if(link <= 0){
		return -1;
	}
	jclass cls_objClass = (*pjEnv)->GetObjectClass(pjEnv, customer);
	jfieldID pinId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "pin", "I");
	jfieldID timer_cntId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass,
			"timer_cnt", "I");
	jfieldID dutyId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "duty", "I");
	jfieldID freqId = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "freq", "I");

	pwm_cust_ rec_buf;
	ret = ulink_cmd_wait((ULINK *) link, cmd, (char *) &rec_buf,
			sizeof(pwm_cust_));
	(*pjEnv)->SetIntField(pjEnv, customer, pinId, rec_buf.pin);
	(*pjEnv)->SetIntField(pjEnv, customer, timer_cntId, rec_buf.timer_cnt);
	(*pjEnv)->SetIntField(pjEnv, customer, dutyId, rec_buf.duty);
	(*pjEnv)->SetIntField(pjEnv, customer, freqId, rec_buf.freq);
	return ret;
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkWaitI2CCmd(JNIEnv *pjEnv,
		jclass clazz, jint link, jint cmd, jobject customer) {
	int ret = 0;
	if(link <= 0){
		return -1;
	}
	jclass cls_objClass = (*pjEnv)->GetObjectClass(pjEnv, customer);
	jfieldID clk_pin = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "clk_pin",
			"I");
	jfieldID sda_pin = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "sda_pin",
			"I");
	jfieldID speed_ = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "speed", "I");
	jfieldID address_ = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "address",
			"I");
	jfieldID w_len = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "w_len", "I");
	jfieldID r_len = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "r_len", "I");
	jfieldID date = (*pjEnv)->GetFieldID(pjEnv, cls_objClass, "date", "I");

	I2C_cust_ rec_buf;
	ret = ulink_cmd_wait((ULINK *) link, cmd, (char *) &rec_buf,
			sizeof(I2C_cust_));
	(*pjEnv)->SetIntField(pjEnv, customer, clk_pin, rec_buf.clk_pin);
	(*pjEnv)->SetIntField(pjEnv, customer, sda_pin, rec_buf.sda_pin);
	(*pjEnv)->SetIntField(pjEnv, customer, speed_, rec_buf.speed);
	(*pjEnv)->SetIntField(pjEnv, customer, address_, rec_buf.address);
	(*pjEnv)->SetIntField(pjEnv, customer, w_len, rec_buf.w_len);
	(*pjEnv)->SetIntField(pjEnv, customer, r_len, rec_buf.r_len);
	(*pjEnv)->SetObjectField(pjEnv, customer, date, rec_buf.date);
	return ret;
}


JNIEXPORT jint JNICALL Java_com_ulink_UlinkNative_sendOnline(JNIEnv *pjEnv,
		jclass clazz, jint dev0, jint dev1) {
	return up2pa_send_online(dev0, dev1);

}

typedef struct {
	u32 pid0;
	u32 pid1;
	u32 dev0;
	u32 dev1;
	u8 keytype;     // �������,0=δ����,1=�Ѽ���
} UP2P_PID_DEV;

JNIEXPORT jobject JNICALL Java_com_ulink_UlinkNative_readPidList
  (JNIEnv * pjEnv, jobject obj, jint maxLen){

	int i, lenlist;
	UP2P_PID_DEV plist[maxLen];
	pid_scan();
	lenlist = pid_list_read(&plist[0], maxLen);
	if (lenlist <= 0)
	{
		return NULL;
	}

	jclass list_cls = (*pjEnv)->FindClass(pjEnv, "java/util/ArrayList");//���ArrayList������

	if(list_cls == NULL)
	{
		return NULL;
	}

	jmethodID list_costruct = (*pjEnv)->GetMethodID(pjEnv, list_cls , "<init>","()V"); //��õù��캯��Id

	jobject list_obj = (*pjEnv)->NewObject(pjEnv, list_cls , list_costruct); //����һ��Arraylist���϶���
	//���Arraylist���е� add()����ID���䷽��ԭ��Ϊ�� boolean add(Object object) ;
	jmethodID list_add  = (*pjEnv)->GetMethodID(pjEnv, list_cls,"add","(Ljava/lang/Object;)Z");

	jclass devcls = (*pjEnv)->FindClass(pjEnv, "com/ulink/UlinkPidDev");
	//��ø����͵Ĺ��캯��  ������Ϊ <init> �������ͱ���Ϊ void �� V
	jmethodID dev_costruct = (*pjEnv)->GetMethodID(pjEnv, devcls , "<init>", "(IIIII)V");
	for(i = 0 ; i < lenlist ; i++)
	{
		jobject dev_obj = (*pjEnv)->NewObject(pjEnv, devcls , dev_costruct , plist[i].pid0, plist[i].pid1, plist[i].dev0, plist[i].dev1, plist[i].keytype);  //����һ������
		(*pjEnv)->CallBooleanMethod(pjEnv, list_obj , list_add , dev_obj); //ִ��Arraylist��ʵ����add����������һ��stu����
	}

	return list_obj ;
}


void JNICALL Java_com_ulink_UlinkNative_readPidListInit(JNIEnv *pjEnv,jclass clazz,jstring ssid,jstring key) {
	const char* c_ssid = (*pjEnv)->GetStringUTFChars(pjEnv, ssid, NULL);
	const char* c_key = (*pjEnv)->GetStringUTFChars(pjEnv, key, NULL);
	smlink_start(c_ssid, c_key);
	pid_list_init();
}


char* jstringTostr(JNIEnv* env, jstring jstr) {
	char* pStr = NULL;

	jclass jstrObj = (*env)->FindClass(env, "java/lang/String");
	jstring encode = (*env)->NewStringUTF(env, "utf-8");
	jmethodID methodId = (*env)->GetMethodID(env, jstrObj, "getBytes",
			"(Ljava/lang/String;)[B");
	jbyteArray byteArray = (jbyteArray)(*env)->CallObjectMethod(env, jstr,
			methodId, encode);
	jsize strLen = (*env)->GetArrayLength(env, byteArray);
	jbyte *jBuf = (*env)->GetByteArrayElements(env, byteArray, JNI_FALSE);

	if (jBuf > 0) {
		pStr = (char*) malloc(strLen + 1);

		if (!pStr) {
			return NULL;
		}

		memcpy(pStr, jBuf, strLen);

		pStr[strLen] = 0;
	}

	(*env)->ReleaseByteArrayElements(env, byteArray, jBuf, 0);

	return pStr;
}



JNIEXPORT jint JNICALL Java_com_ulink_UlinkNative_ulinkSetClock(JNIEnv *env, jobject thiz,
		jint link, jobject param) {
	jint ret = -1;
	if(link <= 0){
		return -1;
	}
	jclass cls = (*env)->GetObjectClass(env, param);
	if(cls){
		u8 buf[255];
		jboolean iscopy;
		settimepacke_st *apptm= (settimepacke_st *)buf;
		memset(apptm,0x00,sizeof(settimepacke_st));

		jfieldID currentmId = (*env)->GetFieldID(env, cls, "currentm", "I");
		jfieldID mon_unixtmId = (*env)->GetFieldID(env, cls, "mon_unixtm", "I");
		jfieldID clkstarId = (*env)->GetFieldID(env, cls, "clkstar", "I");
		jfieldID clkendId = (*env)->GetFieldID(env, cls, "clkend", "I");
		jfieldID clkinvId = (*env)->GetFieldID(env, cls, "clkinv", "I");
		jfieldID weeksId = (*env)->GetFieldID(env, cls, "weeks", "I");
		jfieldID cmdId = (*env)->GetFieldID(env, cls, "cmd", "I");
		jfieldID clk_idxId = (*env)->GetFieldID(env, cls, "clk_idx", "I");
		jfieldID uart_idxId = (*env)->GetFieldID(env, cls, "uart_idx", "I");
		jfieldID ulenId = (*env)->GetFieldID(env, cls, "ulen", "I");
		jfieldID udataId = (*env)->GetFieldID(env, cls, "udata", "Ljava/lang/String;");

		apptm->currentm = (jint)(*env)->GetIntField(env, param, currentmId);
		apptm->mon_unixtm = (jint)(*env)->GetIntField(env, param, mon_unixtmId);
		apptm->settm.clkstar = (jint)(*env)->GetIntField(env, param, clkstarId);
		apptm->settm.clkinv = (jint)(*env)->GetIntField(env, param, clkinvId);
		LOGI("set:currentm:%d,mon_unixtm:%d,clkstar:%d,clkinv:%d",apptm->currentm,apptm->mon_unixtm,apptm->settm.clkstar,apptm->settm.clkinv);
		apptm->settm.clkend = (jint)(*env)->GetIntField(env, param, clkendId);
		apptm->settm.weeks = (jint)(*env)->GetIntField(env, param, weeksId);
		apptm->settm.cmd = (jint)(*env)->GetIntField(env, param, cmdId);
		apptm->settm.ulen = (jint)(*env)->GetIntField(env, param, ulenId);
		apptm->settm.clk_idx = (jint)(*env)->GetIntField(env, param, clk_idxId);
		apptm->settm.uart_idx = (jint)(*env)->GetIntField(env, param, uart_idxId);
		LOGI("set:clkend:%d,weeks:%d,cmd:%d,ulen:%d,clk_idx:%d,uart_idx:%d",apptm->settm.clkend,apptm->settm.weeks,apptm->settm.cmd,apptm->settm.ulen,apptm->settm.clk_idx,apptm->settm.uart_idx);
		jstring udata = (jstring)(*env)->GetObjectField(env, param, udataId);
		const char *localudata = NULL;
		if(udata != NULL){
			localudata = (*env)->GetStringUTFChars(env, udata, &iscopy);
			LOGI("set:localudata:%s",localudata);
			/* ��ȡ��Ҫ���洮������*/
			if(apptm->settm.ulen > 0 && localudata != NULL )
			{
				//printf("\tuart_idx=%d;uartdata=%s\n",apptm->settm.uart_idx,localudata);
				memcpy(apptm->settm.udata,localudata,apptm->settm.ulen);
			}
		}

		ulink_cmd_send((ULINK *)link, CMD_CLOCK_SET, apptm, sizeof(settimepacke_st)+apptm->settm.ulen);
		ret = ulink_cmd_wait((ULINK *)link, CMD_CLOCK_SET_ACK, NULL, 0);
		LOGI("set:ret:%d",ret);
		(*env)->ReleaseStringUTFChars(env, udata, localudata);
	}
	return ret;
}


JNIEXPORT jobject JNICALL Java_com_ulink_UlinkNative_ulinkGetClock(JNIEnv *env, jobject thiz,
		jint link, jint baseTM, jint item) {
	if(link <= 0){
		return -1;
	}
	    jclass cls = (*env)->FindClass(env, "com/ulink/UlinkTimer");
	    jmethodID id = (*env)->GetMethodID(env, cls, "<init>", "()V");
	    jobject param = (*env)->NewObjectA(env, cls, id, 0);
		jfieldID clkstarId = (*env)->GetFieldID(env, cls, "clkstar", "I");
		jfieldID clkendId = (*env)->GetFieldID(env, cls, "clkend", "I");
		jfieldID clkinvId = (*env)->GetFieldID(env, cls, "clkinv", "I");
		jfieldID weeksId = (*env)->GetFieldID(env, cls, "weeks", "I");
		jfieldID cmdId = (*env)->GetFieldID(env, cls, "cmd", "I");
		jfieldID clk_idxId = (*env)->GetFieldID(env, cls, "clk_idx", "I");
		jfieldID uart_idxId = (*env)->GetFieldID(env, cls, "uart_idx", "I");
		jfieldID ulenId = (*env)->GetFieldID(env, cls, "ulen", "I");
		jfieldID udataId = (*env)->GetFieldID(env, cls, "udata", "Ljava/lang/String;");
        u8 recbuf[128];
        timestamp_st *gettm = NULL;
       // LOGI("GetClock:%d,%d,%d",link, baseTM, item);

    	u8 buf[255];
    	time_t tm;
    	settimepacke_st *apptm= (settimepacke_st *)buf;
    	memset(apptm,0x00,sizeof(settimepacke_st));
    	time(&tm);
    	apptm->currentm = tm;
    	apptm->mon_unixtm = baseTM;
    	apptm->settm.clk_idx = item;
    	//LOGI("GetClock:%d,%d", baseTM, apptm->settm.clk_idx);
    	ulink_cmd_send((ULINK *)link, CMD_CLOCK_GET, apptm, sizeof(settimepacke_st));
    	//LOGI("0000");
        if(ulink_cmd_wait((ULINK *)link, CMD_CLOCK_GET_ACK,recbuf, 100) > 0){
        	//LOGI("1111");
        	gettm = (timestamp_st *)recbuf;
        	(*env)->SetIntField(env, param, clkstarId, gettm->clkstar);
        	(*env)->SetIntField(env, param, clkendId, gettm->clkend);
        	(*env)->SetIntField(env, param, clkinvId, gettm->clkinv);
        	(*env)->SetIntField(env, param, weeksId, gettm->weeks);
        	(*env)->SetIntField(env, param, cmdId, gettm->cmd);
        	(*env)->SetIntField(env, param, clk_idxId, gettm->clk_idx);
        	(*env)->SetIntField(env, param, uart_idxId, gettm->uart_idx);
        	(*env)->SetIntField(env, param, ulenId, gettm->ulen);
        	(*env)->SetObjectField(env, param, udataId, strToJstring(env, gettm->udata));
    		//LOGI("read:clkstar:%d,clkend:%d,clkinv:%d,weeks:%d,cmd:%d,clk_idx:%d,uart_idx:%d,ulen:%d,localudata:%s",
    		//		 gettm->clkstar, gettm->clkend, gettm->clkinv, gettm->weeks, gettm->cmd, gettm->clk_idx,gettm->uart_idx,gettm->ulen, gettm->udata);
        }else{
        	//LOGI("2222");
        	param = NULL;
        }

	    return param;
}


void JNICALL Java_com_ulink_UlinkNative_readPidListFinish(JNIEnv *pjEnv,jclass clazz) {
	smlink_stop();
}

void JNICALL Java_com_ulink_UlinkNative_ulinkBorderBegin(JNIEnv *pjEnv,
		jclass clazz) {
	//ulink_border_begin();
}

void JNICALL Java_com_ulink_UlinkNative_ulinkBorderEnd(JNIEnv *pjEnv,
		jclass clazz) {
	//ulink_border_end();
}


void JNICALL Java_com_ulink_UlinkNative_ulinkOnlineInit(JNIEnv *pjEnv,
		jclass clazz) {
	Online_Init();
}


jint JNICALL Java_com_ulink_UlinkNative_ulinkOnlineCheck(JNIEnv *pjEnv, jclass clazz,
		jstring dev_id) {
	const char* devid = (*pjEnv)->GetStringUTFChars(pjEnv, dev_id, NULL);
	return Online_Check(devid);
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkGetError(JNIEnv *pjEnv, jclass clazz) {
	return ulink_get_error();
}

jint JNICALL Java_com_ulink_UlinkNative_ulinkSendCmdChar(JNIEnv *pjEnv,
		jclass clazz, jint link, jint cmd, jbyteArray param, jint len) {

	//char* send_buf = (*pjEnv)->GetStringUTFChars(pjEnv, param, NULL);
	int i;
	if(link <= 0){
		return -1;
	}

	jbyte *jbarray = (jbyte *) malloc(len * sizeof(jbyte));

	(*pjEnv)->GetByteArrayRegion(pjEnv,param, 0, len, jbarray);

	jbyte *dDate = (jbyte*) jbarray;

//	for (i = 0; i < len; i++) {
//		LOGI("0x%02x,",dDate[i]);
//	}
	return ulink_cmd_send((ULINK *) link, cmd, dDate, len);
}

#endif
